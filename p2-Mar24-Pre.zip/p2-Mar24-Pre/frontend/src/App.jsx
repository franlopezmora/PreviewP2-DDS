function App() {

  // lógica funcional previa a la construcción del resultado renderizable del componente


  return (
    <div className="container mt-5">
      <h3 className="text-center fw-bold mb-5 display-1">🚀 Desarrollo del parcial 2</h3>
    </div>
  );
}

export default App;
